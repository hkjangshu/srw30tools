HOW TO PATCH THE PROBLEMATIC PRONOUNS TRANSLATION
--------------------------------------------------
1. Start CriPakGUI.exe in the "CriPakGUISRW30" directory
2. Click "File -> Open CPK" and go to your game directory: Steam > steamapps > common > Super Robot Wars 30 > pc > data > mission
Then select "mission_est010_en.cpk"
3. Click "Patch CPK"
4. For the first path, select the "Mod" directory (it contains a file named "580.bin")
5. For the second path, enter the output path for your new patched cpk (for example mission_est010_en_patched.cpk)
6. IMPORTANT: DO check "Don't use CRILAYLA compression"
7. Click "Patch CPK" and wait
8. Rename your original "mission_est010_en.cpk" to something else like "mission_est010_en.cpk.bak" 
and rename your patched .cpk to "mission_est010_en.cpk"

DONE

HOW TO MAKE YOUR OWN MODS
-------------------------
1. Start CriPakGUI.exe in the "CriPakGUISRW30" directory
2. Click "File -> Open CPK" and go to your game directory: Steam > steamapps > common > Super Robot Wars 30 > pc
Then open any CPK file
3. Click "Extract Files" and select the output directory. It will extract some encrypted files. You can't read them
4. Open a cmd prompt and cd your way to the directory above the one that contains your extracted files
5. run "quickbms.exe srw30cryala.bms your_directory_with_extracted_files output_directory". It will decrypt all the files
6. Mod your files
7. For each file you modded you can double click on "quickbms.exe" and first select "srw30encrypt.bms" then select 
your modded file, then select an output directory
8. Rename the output file this way: "number_of_the_file.bin" (for example: 130.bin)
9. Repeat the steps in "HOW TO PATCH THE PROBLEMATIC PRONOUNS TRANSLATION" but with the name of the .cpk you want to 
mod and the name of your .bin file

DONE
 